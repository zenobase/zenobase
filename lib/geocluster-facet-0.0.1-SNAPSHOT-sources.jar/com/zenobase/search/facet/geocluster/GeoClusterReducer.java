package com.zenobase.search.facet.geocluster;

import java.util.List;

import org.elasticsearch.common.collect.Lists;
import org.elasticsearch.common.unit.DistanceUnit;

public class GeoClusterReducer {

	private final DistanceUnit unit = DistanceUnit.KILOMETERS;
	private final int factor;

	public GeoClusterReducer(int factor) {
		this.factor = factor;
	}

	public List<GeoCluster> reduce(Iterable<GeoCluster> clusters) {
		GeoBoundingBox bounds = getBounds(clusters);
		double maxDistance = bounds != null ? bounds.size(unit) / factor : 0.0;
		List<GeoCluster> reduced = Lists.newLinkedList(clusters);
		REDUCE: while (true) {
			for (int i = 0; i < reduced.size(); ++i) {
				for (int j = i + 1; j < reduced.size(); ++j) {
					GeoCluster a = reduced.get(i);
					GeoCluster b = reduced.get(j);
					if (GeoPoints.distance(a.center(), b.center(), unit) <= maxDistance) {
						a.add(b);
						reduced.remove(b);
						continue REDUCE;
					}
				}
			}
			break;
		}
		return reduced;
	}

	private static GeoBoundingBox getBounds(Iterable<GeoCluster> clusters) {
		GeoBoundingBox bounds = null;
		for (GeoCluster cluster : clusters) {
			if (bounds != null) {
				bounds = bounds.extend(cluster.bounds());
			} else {
				bounds = cluster.bounds();
			}
		}
		return bounds;
	}
}
